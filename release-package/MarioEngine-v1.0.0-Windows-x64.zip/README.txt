﻿# MarioEngine v1.0.0

## Como ejecutar
1. Extrae todos los archivos a una carpeta
2. Ejecuta MarioEngine.exe

## Controles
- Click derecho + arrastrar: Rotar camara
- WASD: Mover camara
- Scroll: Zoom
- Click izquierdo en Scene: Seleccionar objeto
- W/E/R: Cambiar modo (Mover/Rotar/Escalar)

## Requisitos
- Windows 10/11 64-bit
- Tarjeta grafica compatible con OpenGL 3.3

## Soporte
Reporta problemas en: https://github.com/tu-usuario/MarioEngine/issues
